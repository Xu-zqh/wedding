const envList = [{"envId":"test-e0bf8a","alias":"test"}]
const isMac = true
module.exports = {
    envList,
    isMac
}