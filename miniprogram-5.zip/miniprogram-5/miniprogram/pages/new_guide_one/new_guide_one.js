// pages/new_guide_one/new_guide_one.js
const app = getApp()
Page({

	/**
	 * 页面的初始数据
	 */
	data: {
		userinfo: wx.getStorageSync('user'),
        openid: wx.getStorageSync('userOpenid'),
        datalist: "",
	},

	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad(options) {
		this.getMyInvite();
	},
	async getMyInvite() {
        this.setData({
            userinfo: wx.getStorageSync('user')
        })
        const that = this;
        const res = await app.call({
            // 云函数名称
            name: 'wishes-520',
            // 传给云函数的参数
            data: {
                type: 'getMyInvite'
            }
        })
        that.setData({
            datalist: res.data,
            day: res.data ? that.timesize(that.data.newtime, res.data.memorialDayTime) : 'xxxx',
            userinfo: wx.getStorageSync('user')
        })
        wx.stopPullDownRefresh();
	}, 
	async updateTa() {
        this.getMyInvite();
        const that = this;
        try {
            const res = await app.call({
                // 云函数名称
                name: 'wishes-520',
                // 传给云函数的参数
                data: {
                    type: 'updateMyInvite',
                    _id: that.data.datalist._id
                }
            })
            that.offMask();
            wx.showToast({
                title: '修改成功',
                icon: 'success'
            })
            wx.removeStorageSync('recipientId');
            setTimeout(() => {
                wx.reLaunch({
                    url: '../minedata/index',
                })
            }, 1000)
        } catch (error) {
            wx.showToast({
                title: '请邀请Ta\n 以激活功能',
                icon: 'error'
            })
            that.offMask();
        }
	},

	onMask() {
        if (wx.getStorageSync('recipientId')) {
            this.setData({
                maskshow: true
            })
        }
	},
	offMask() {
        this.setData({
            maskshow: false
        })
    },
	/**
	 * 生命周期函数--监听页面初次渲染完成
	 */
	onReady() {

	},

	/**
	 * 生命周期函数--监听页面显示
	 */
	onShow() {

	},

	/**
	 * 生命周期函数--监听页面隐藏
	 */
	onHide() {

	},

	/**
	 * 生命周期函数--监听页面卸载
	 */
	onUnload() {

	},

	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh() {
        this.getMyInvite();
    },

	/**
	 * 页面上拉触底事件的处理函数
	 */
	onReachBottom() {

	},

	/**
	 * 用户点击右上角分享
	 */
	onShareAppMessage() {

	}
})